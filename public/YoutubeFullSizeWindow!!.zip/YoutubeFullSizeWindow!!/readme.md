# 使い方

1. [まずこちらのリンクに移動し](chrome://extensions/)
2. Google 拡張機能のデベロッパーモードを ON にして
3. 解凍した「YoutubeFullSizeWindow!!」ファイルをドラッグオンドロップしてください

[参考リンク](https://original-game.com/how-to-make-chrome-extensions/)
